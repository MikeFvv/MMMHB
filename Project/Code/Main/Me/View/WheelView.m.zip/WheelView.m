//
//  WheelView.m
//  Project
//
//  Created by fangyuan on 2019/2/18.
//  Copyright © 2019 CDJay. All rights reserved.
//转盘
#define DEGREES_TO_RADIANS(angle) ((angle) / 180.0 * M_PI)
#import "WheelView.h"
@interface WheelView()
@property(nonatomic,strong)NSArray *dataArray;//奖品数据
@property(nonatomic,assign)float targetS;//总路程

@property(nonatomic,assign)float a;
@property(nonatomic,assign)float s;
@property(nonatomic,assign)float vt;
@property(nonatomic,assign)float t;
@property(nonatomic,assign)float v0;
@property(nonatomic,strong)NSTimer *timer;
@property(nonatomic,assign) BOOL isStop;
@end

@implementation WheelView

- (instancetype)initWithFrame:(CGRect)frame dataArray:(NSArray *)array{
    self = [super initWithFrame:frame];
    if (self) {
        self.dataArray = array;
        self.targetS = 360 * 20 + 90;// 10圈 + 90度
        self.v0 = 50;
        float tt = 3.0;
        self.a = (self.targetS - self.v0 * tt) * 2/(tt * tt);
        self.vt = 0;
        self.t = 0;
        self.a = 105;
        self.s = 0;
        self.isStop = NO;
        NSInteger width = 300;
        self.containView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pan"]];
        self.containView.contentMode = UIViewContentModeScaleAspectFit;
        self.containView.frame = CGRectMake(0, 0, width, width);
        self.containView.center = CGPointMake(frame.size.width/2.0, frame.size.height/2.0);
        self.containView.backgroundColor = Color_9;
        [self addSubview:self.containView];
        
        self.needleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"zhen"]];
        self.needleView.contentMode = UIViewContentModeScaleAspectFit;
        self.needleView.backgroundColor = [UIColor clearColor];
        self.needleView.frame = CGRectMake(0, 0, width/2.0, width/2.0);
        self.needleView.center = self.containView.center;
        [self addSubview:self.needleView];
        
        [self startScroll];
//        self.timer = [NSTimer scheduledTimerWithTimeInterval:0.02 target:self selector:@selector(update) userInfo:nil repeats:YES];
    }
    return self;
}

-(void)update{
    if(self.isStop == YES)
        return;
    self.t += 0.02;
    self.vt = self.a * self.t + self.v0;
    float s = self.v0 * self.t + 0.5 * self.vt * self.t;
    if(self.a > 0)
        self.a += 0.8;
//    else
//        self.a += 0.5;
    self.needleView.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(s + self.s));
    NSLog(@"%f",s);
    if(self.t >= 3){
        self.a = -self.a * 0.3;
        self.t = 0;
        self.s = s;
        self.v0 = self.vt;
    }else if(self.vt <= 0){
        self.isStop = YES;
    }
}
-(void)startScroll{
    CABasicAnimation *animation =  [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    //默认是顺时针效果，若将fromValue和toValue的值互换，则为逆时针效果
    animation.fromValue = [NSNumber numberWithFloat:0];
    animation.toValue =  [NSNumber numberWithFloat:M_PI * 20.5];
    animation.duration  = 7.0;                  //一次时间
    animation.autoreverses = NO;                         //是否自动回倒
    animation.fillMode =kCAFillModeForwards;
    animation.removedOnCompletion = NO;           //设置进入后台动画不停止
    animation.repeatCount = 0 ;            //重复次数
    animation.delegate = nil;                    //动画代理
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [self.needleView.layer addAnimation:animation forKey:nil];
}


-(void)createPrize{
    for (NSDictionary *dic in self.dataArray) {
    }
}
@end
