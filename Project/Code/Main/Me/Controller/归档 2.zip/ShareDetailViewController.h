//
//  ShareDetailViewController.h
//  Project
//
//  Created by fy on 2019/1/3.
//  Copyright © 2019 CDJay. All rights reserved.
//

#import "SuperViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ShareDetailViewController : SuperViewController
@property(nonatomic,strong)NSDictionary *shareInfo;
@property(nonatomic,strong)NSString *shareUrl;
@end

NS_ASSUME_NONNULL_END
